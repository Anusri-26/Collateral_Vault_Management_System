use anchor_lang::prelude::*;
use anchor_spl::token::{self, TokenAccount, Token, Transfer};

declare_id!("Fg6PaFpoGXkYsidMpWTK6W2BeZ7FEfcYkgV6h4g9rS3g");

#[program]
pub mod collateral_vault {
    use super::*;

    pub fn initialize_vault(ctx: Context<InitializeVault>) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        vault.owner = ctx.accounts.user.key();
        vault.token_account = ctx.accounts.vault_token_account.key();
        vault.total_balance = 0;
        vault.locked_balance = 0;
        vault.available_balance = 0;
        vault.total_deposited = 0;
        vault.total_withdrawn = 0;
        vault.created_at = Clock::get()?.unix_timestamp;
        vault.bump = *ctx.bumps.get("vault").unwrap();
        Ok(())
    }

    pub fn deposit(ctx: Context<Deposit>, amount: u64) -> Result<()> {
        require!(amount > 0, ErrorCode::InvalidAmount);

        let cpi_accounts = Transfer {
            from: ctx.accounts.user_token_account.to_account_info(),
            to: ctx.accounts.vault_token_account.to_account_info(),
            authority: ctx.accounts.user.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        token::transfer(
            CpiContext::new(cpi_program, cpi_accounts),
            amount,
        )?;

        let vault = &mut ctx.accounts.vault;
        vault.total_balance = vault.total_balance.checked_add(amount).unwrap();
        vault.available_balance = vault.available_balance.checked_add(amount).unwrap();
        vault.total_deposited = vault.total_deposited.checked_add(amount).unwrap();

        emit!(DepositEvent {
            user: ctx.accounts.user.key(),
            amount,
            new_balance: vault.total_balance,
            timestamp: Clock::get()?.unix_timestamp,
        });

        Ok(())
    }

    pub fn withdraw(ctx: Context<Withdraw>, amount: u64) -> Result<()> {
        require!(amount > 0, ErrorCode::InvalidAmount);

        let vault = &mut ctx.accounts.vault;
        require!(vault.available_balance >= amount, ErrorCode::InsufficientFunds);

        let seeds = &[b"vault", vault.owner.as_ref(), &[vault.bump]];
        let signer = &[&seeds[..]];
        let cpi_accounts = Transfer {
            from: ctx.accounts.vault_token_account.to_account_info(),
            to: ctx.accounts.user_token_account.to_account_info(),
            authority: ctx.accounts.vault_authority.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        token::transfer(
            CpiContext::new_with_signer(cpi_program, cpi_accounts, signer),
            amount,
        )?;

        vault.total_balance = vault.total_balance.checked_sub(amount).unwrap();
        vault.available_balance = vault.available_balance.checked_sub(amount).unwrap();
        vault.total_withdrawn = vault.total_withdrawn.checked_add(amount).unwrap();

        emit!(WithdrawEvent {
            user: ctx.accounts.user.key(),
            amount,
            new_balance: vault.total_balance,
            timestamp: Clock::get()?.unix_timestamp,
        });

        Ok(())
    }

    pub fn lock_collateral(ctx: Context<LockUnlock>, amount: u64) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        require!(ctx.accounts.authority.is_signer, ErrorCode::Unauthorized);
        require!(vault.available_balance >= amount, ErrorCode::InsufficientFunds);

        vault.locked_balance = vault.locked_balance.checked_add(amount).unwrap();
        vault.available_balance = vault.available_balance.checked_sub(amount).unwrap();

        emit!(LockEvent {
            vault: vault.key(),
            amount,
            new_locked: vault.locked_balance,
            timestamp: Clock::get()?.unix_timestamp,
        });

        Ok(())
    }

    pub fn unlock_collateral(ctx: Context<LockUnlock>, amount: u64) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        require!(ctx.accounts.authority.is_signer, ErrorCode::Unauthorized);
        require!(vault.locked_balance >= amount, ErrorCode::InvalidUnlockAmount);

        vault.locked_balance = vault.locked_balance.checked_sub(amount).unwrap();
        vault.available_balance = vault.available_balance.checked_add(amount).unwrap();

        emit!(UnlockEvent {
            vault: vault.key(),
            amount,
            new_locked: vault.locked_balance,
            timestamp: Clock::get()?.unix_timestamp,
        });

        Ok(())
    }

    pub fn transfer_collateral(ctx: Context<TransferCollateral>, amount: u64) -> Result<()> {
        require!(amount > 0, ErrorCode::InvalidAmount);
        let from_vault = &mut ctx.accounts.from_vault;
        let to_vault = &mut ctx.accounts.to_vault;
        require!(ctx.accounts.authority.is_signer, ErrorCode::Unauthorized);
        require!(from_vault.available_balance >= amount, ErrorCode::InsufficientFunds);

        from_vault.total_balance = from_vault.total_balance.checked_sub(amount).unwrap();
        from_vault.available_balance = from_vault.available_balance.checked_sub(amount).unwrap();
        from_vault.total_withdrawn = from_vault.total_withdrawn.checked_add(amount).unwrap();

        to_vault.total_balance = to_vault.total_balance.checked_add(amount).unwrap();
        to_vault.available_balance = to_vault.available_balance.checked_add(amount).unwrap();
        to_vault.total_deposited = to_vault.total_deposited.checked_add(amount).unwrap();

        emit!(TransferEvent {
            from: from_vault.key(),
            to: to_vault.key(),
            amount,
            timestamp: Clock::get()?.unix_timestamp,
        });

        Ok(())
    }
}

#[derive(Accounts)]
pub struct InitializeVault<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(
        init,
        seeds = [b"vault", user.key().as_ref()],
        bump,
        payer = user,
        space = 8 + CollateralVault::LEN,
    )]
    pub vault: Account<'info, CollateralVault>,

    #[account(mut)]
    pub vault_token_account: Account<'info, TokenAccount>,

    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct Deposit<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(
        mut,
        seeds = [b"vault", user.key().as_ref()],
        bump = vault.bump,
    )]
    pub vault: Account<'info, CollateralVault>,

    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,

    #[account(mut, address = vault.token_account)]
    pub vault_token_account: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct Withdraw<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(
        mut,
        seeds = [b"vault", user.key().as_ref()],
        bump = vault.bump,
    )]
    pub vault: Account<'info, CollateralVault>,

    #[account(seeds = [b"vault_auth", vault.key().as_ref()], bump)]
    pub vault_authority: UncheckedAccount<'info>,

    #[account(mut, address = vault.token_account)]
    pub vault_token_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct LockUnlock<'info> {
    #[account(signer)]
    pub authority: UncheckedAccount<'info>,

    #[account(mut, seeds = [b"vault", vault.owner.as_ref()], bump = vault.bump)]
    pub vault: Account<'info, CollateralVault>,
}

#[derive(Accounts)]
pub struct TransferCollateral<'info> {
    #[account(signer)]
    pub authority: UncheckedAccount<'info>,

    #[account(mut)]
    pub from_vault: Account<'info, CollateralVault>,

    #[account(mut)]
    pub to_vault: Account<'info, CollateralVault>,
}

#[account]
pub struct CollateralVault {
    pub owner: Pubkey,
    pub token_account: Pubkey,
    pub total_balance: u64,
    pub locked_balance: u64,
    pub available_balance: u64,
    pub total_deposited: u64,
    pub total_withdrawn: u64,
    pub created_at: i64,
    pub bump: u8,
}
impl CollateralVault {
    pub const LEN: usize = 32 + 32 + 8 + 8 + 8 + 8 + 8 + 8 + 1;
}

#[event]
pub struct DepositEvent {
    pub user: Pubkey,
    pub amount: u64,
    pub new_balance: u64,
    pub timestamp: i64,
}
#[event]
pub struct WithdrawEvent {
    pub user: Pubkey,
    pub amount: u64,
    pub new_balance: u64,
    pub timestamp: i64,
}
#[event]
pub struct LockEvent {
    pub vault: Pubkey,
    pub amount: u64,
    pub new_locked: u64,
    pub timestamp: i64,
}
#[event]
pub struct UnlockEvent {
    pub vault: Pubkey,
    pub amount: u64,
    pub new_locked: u64,
    pub timestamp: i64,
}
#[event]
pub struct TransferEvent {
    pub from: Pubkey,
    pub to: Pubkey,
    pub amount: u64,
    pub timestamp: i64,
}

#[error_code]
pub enum ErrorCode {
    #[msg("Invalid amount")]
    InvalidAmount,
    #[msg("Insufficient funds")]
    InsufficientFunds,
    #[msg("Unauthorized")]
    Unauthorized,
    #[msg("Invalid unlock amount")]
    InvalidUnlockAmount,
}
