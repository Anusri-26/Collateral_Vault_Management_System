import * as anchor from "@project-serum/anchor";
import { Program } from "@project-serum/anchor";
import { CollateralVault } from "../target/types/collateral_vault";
import { TOKEN_PROGRAM_ID, createMint, getOrCreateAssociatedTokenAccount, mintTo } from "@solana/spl-token";

describe("collateral_vault", () => {
  const provider = anchor.AnchorProvider.local();
  anchor.setProvider(provider);
  const program = anchor.workspace.CollateralVault as Program<CollateralVault>;

  it("initialize, deposit, withdraw flow", async () => {
    const user = provider.wallet;
    const mint = await createMint(provider.connection, user.payer, user.publicKey, null, 6);
    const userAta = await getOrCreateAssociatedTokenAccount(provider.connection, user.payer, mint, user.publicKey);
    await mintTo(provider.connection, user.payer, mint, userAta.address, user.payer, 1_000_000);

    const [vaultPda, vaultBump] = await anchor.web3.PublicKey.findProgramAddress(
      [Buffer.from("vault"), user.publicKey.toBuffer()],
      program.programId
    );

    const vaultAta = await getOrCreateAssociatedTokenAccount(provider.connection, user.payer, mint, vaultPda, true);

    await program.methods.initializeVault()
      .accounts({
        user: user.publicKey,
        vault: vaultPda,
        vaultTokenAccount: vaultAta.address,
        systemProgram: anchor.web3.SystemProgram.programId,
        rent: anchor.web3.SYSVAR_RENT_PUBKEY,
        tokenProgram: TOKEN_PROGRAM_ID,
      })
      .rpc();

    await program.methods.deposit(new anchor.BN(1000))
      .accounts({
        user: user.publicKey,
        vault: vaultPda,
        userTokenAccount: userAta.address,
        vaultTokenAccount: vaultAta.address,
        tokenProgram: TOKEN_PROGRAM_ID,
      })
      .rpc();

    const [vaultAuth, authBump] = await anchor.web3.PublicKey.findProgramAddress(
      [Buffer.from("vault_auth"), vaultPda.toBuffer()],
      program.programId
    );

    await program.methods.withdraw(new anchor.BN(500))
      .accounts({
        user: user.publicKey,
        vault: vaultPda,
        vaultAuthority: vaultAuth,
        vaultTokenAccount: vaultAta.address,
        userTokenAccount: userAta.address,
        tokenProgram: TOKEN_PROGRAM_ID,
      })
      .rpc();

    const vaultAccount = await program.account.collateralVault.fetch(vaultPda);
    console.log("vaultAccount total_balance:", vaultAccount.totalBalance.toString());
  });
});