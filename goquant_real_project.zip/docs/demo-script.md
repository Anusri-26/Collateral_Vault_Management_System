# Demo Script (summary)

1. Intro and objective.
2. Show architecture and PDA derivation.
3. Walkthrough of key instructions in programs/collateral_vault/src/lib.rs.
4. Start solana-test-validator and run anchor test to demonstrate deposit/withdraw flows.
5. Run backend and use curl to simulate initialize/deposit/withdraw and view DB.
6. Summarize security and next steps.
