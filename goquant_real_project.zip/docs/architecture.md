# Architecture — Collateral Vault (summary)

- Vaults are PDAs derived with seed: ["vault", user_pubkey]
- Vault stores balances and references vault token ATA.
- Vault authority PDA: ["vault_auth", vault_pubkey] used for signer when moving tokens out.
- Deposit: user -> vault token account (SPL Token transfer via CPI)
- Withdraw: vault token account -> user (signed by vault authority PDA via CPI)
- Lock/Unlock: invoked by position manager to reserve/unreserve collateral.
- Transfer collateral: accounting-only transfer between vaults for settlements in demo.
