# CPI Flow Summary

- Deposit: client signs transfer; program only updates state after successful token CPI.
- Withdraw: program performs `token::transfer` with `CpiContext::new_with_signer` where the signer is the vault authority PDA.
- Lock/Unlock: internal state updates callable via CPI.
