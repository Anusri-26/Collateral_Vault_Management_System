# Security Notes

- Use checked arithmetic (`checked_add`, `checked_sub`) to avoid over/underflow.
- Validate amounts > 0.
- Enforce authority constraints; in production use a VaultAuthority account storing allowed program Pubkeys.
- Add withdrawal delays, rate-limiting, multi-sig for production.
