CREATE TABLE IF NOT EXISTS vault_accounts (
  id SERIAL PRIMARY KEY,
  owner_pubkey TEXT NOT NULL,
  vault_pubkey TEXT NOT NULL,
  token_account_pubkey TEXT NOT NULL,
  total_balance BIGINT DEFAULT 0,
  locked_balance BIGINT DEFAULT 0,
  available_balance BIGINT DEFAULT 0,
  total_deposited BIGINT DEFAULT 0,
  total_withdrawn BIGINT DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS transactions (
  id SERIAL PRIMARY KEY,
  vault_pubkey TEXT NOT NULL,
  tx_type TEXT NOT NULL,
  amount BIGINT NOT NULL,
  tx_sig TEXT,
  timestamp TIMESTAMP DEFAULT NOW()
);
