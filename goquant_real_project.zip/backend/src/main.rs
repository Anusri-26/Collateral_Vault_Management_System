use actix_web::{web, App, HttpServer, Responder, HttpResponse};
use serde::{Deserialize, Serialize};
use sqlx::PgPool;
use std::env;

#[derive(Serialize)]
struct Health { status: &'static str }

async fn health() -> impl Responder {
    web::Json(Health { status: "ok" })
}

#[derive(Deserialize)]
struct InitVaultReq { owner_pubkey: String, vault_token_account: String }

#[derive(Deserialize)]
struct TxReq { owner_pubkey: String, amount: i64 }

async fn init_vault(pool: web::Data<PgPool>, req: web::Json<InitVaultReq>) -> impl Responder {
    let q = "INSERT INTO vault_accounts (owner_pubkey, vault_pubkey, token_account_pubkey) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING";
    let vault_pubkey = format!("vault_{}", &req.owner_pubkey[..8]);
    let _ = sqlx::query(q).bind(&req.owner_pubkey).bind(&vault_pubkey).bind(&req.vault_token_account).execute(pool.get_ref()).await;
    HttpResponse::Ok().json(serde_json::json!({"status":"initialized","vault_pubkey":vault_pubkey}))
}

async fn deposit(pool: web::Data<PgPool>, req: web::Json<TxReq>) -> impl Responder {
    let q = "UPDATE vault_accounts SET total_balance = total_balance + $1, available_balance = available_balance + $1, total_deposited = total_deposited + $1 WHERE owner_pubkey = $2";
    let _ = sqlx::query(q).bind(req.amount).bind(&req.owner_pubkey).execute(pool.get_ref()).await;
    let ins = "INSERT INTO transactions (vault_pubkey, tx_type, amount) VALUES ($1,$2,$3)";
    let vault_pubkey = format!("vault_{}", &req.owner_pubkey[..8]);
    let _ = sqlx::query(ins).bind(&vault_pubkey).bind("deposit").bind(req.amount).execute(pool.get_ref()).await;
    HttpResponse::Ok().json(serde_json::json!({"status":"deposited","amount":req.amount}))
}

async fn withdraw(pool: web::Data<PgPool>, req: web::Json<TxReq>) -> impl Responder {
    let row = sqlx::query!("SELECT available_balance FROM vault_accounts WHERE owner_pubkey=$1", &req.owner_pubkey)
        .fetch_one(pool.get_ref()).await;
    if let Err(_) = row {
        return HttpResponse::BadRequest().json(serde_json::json!({"error":"vault not found"}));
    }
    let avail: i64 = row.unwrap().available_balance.unwrap_or(0);
    if avail < req.amount {
        return HttpResponse::BadRequest().json(serde_json::json!({"error":"insufficient available balance","available":avail}));
    }
    let q = "UPDATE vault_accounts SET total_balance = total_balance - $1, available_balance = available_balance - $1, total_withdrawn = total_withdrawn + $1 WHERE owner_pubkey = $2";
    let _ = sqlx::query(q).bind(req.amount).bind(&req.owner_pubkey).execute(pool.get_ref()).await;
    let ins = "INSERT INTO transactions (vault_pubkey, tx_type, amount) VALUES ($1,$2,$3)";
    let vault_pubkey = format!("vault_{}", &req.owner_pubkey[..8]);
    let _ = sqlx::query(ins).bind(&vault_pubkey).bind("withdraw").bind(req.amount).execute(pool.get_ref()).await;
    HttpResponse::Ok().json(serde_json::json!({"status":"withdrawn","amount":req.amount}))
}

async fn get_balance(pool: web::Data<PgPool>, path: web::Path<String>) -> impl Responder {
    let owner = path.into_inner();
    let row = sqlx::query!("SELECT total_balance, locked_balance, available_balance FROM vault_accounts WHERE owner_pubkey=$1", &owner)
        .fetch_one(pool.get_ref()).await;
    if let Err(_) = row {
        return HttpResponse::NotFound().json(serde_json::json!({"error":"vault not found"}));
    }
    let r = row.unwrap();
    HttpResponse::Ok().json(serde_json::json!({
        "total_balance": r.total_balance.unwrap_or(0),
        "locked_balance": r.locked_balance.unwrap_or(0),
        "available_balance": r.available_balance.unwrap_or(0)
    }))
}

async fn get_transactions(pool: web::Data<PgPool>, path: web::Path<String>) -> impl Responder {
    let owner = path.into_inner();
    let vault_pubkey = format!("vault_{}", &owner[..8]);
    let rows = sqlx::query!("SELECT tx_type, amount, tx_sig, timestamp FROM transactions WHERE vault_pubkey=$1 ORDER BY timestamp DESC LIMIT 50", &vault_pubkey)
        .fetch_all(pool.get_ref()).await;
    if let Err(_) = rows {
        return HttpResponse::Ok().json(serde_json::json!({"transactions": []}));
    }
    let out: Vec<_> = rows.unwrap().into_iter().map(|r| {
        serde_json::json!({"tx_type": r.tx_type, "amount": r.amount, "tx_sig": r.tx_sig, "timestamp": r.timestamp})
    }).collect();
    HttpResponse::Ok().json(serde_json::json!({"transactions": out}))
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    let database_url = env::var("DATABASE_URL").unwrap_or("postgres://postgres:postgres@localhost/vault".to_string());
    let pool = PgPool::connect(&database_url).await.expect("DB connect");

    println!("Starting backend at http://127.0.0.1:8080");
    HttpServer::new(move || {
        App::new()
            .app_data(web::Data::new(pool.clone()))
            .route("/health", web::get().to(health))
            .route("/vault/initialize", web::post().to(init_vault))
            .route("/vault/deposit", web::post().to(deposit))
            .route("/vault/withdraw", web::post().to(withdraw))
            .route("/vault/balance/{owner}", web::get().to(get_balance))
            .route("/vault/transactions/{owner}", web::get().to(get_transactions))
    })
    .bind(("127.0.0.1", 8080))?
    .run()
    .await
}